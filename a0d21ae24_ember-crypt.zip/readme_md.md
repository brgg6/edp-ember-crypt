# Ember Crypt — Event-Driven Programming (EDP) Project

An event-driven browser game built with **React**, **Vite**, and a local **in-memory Event Bus / Queue**. All gameplay actions emit structured events with JSON payloads that are processed by decoupled event handlers and displayed in real time via the built-in EDP Event Log and Pipeline visualizer.

---

## Project Structure

```text
├── src/
│   ├── components/
│   │   ├── edp/
│   │   │   ├── EventLog.jsx      # Live stream of emitted events & payloads
│   │   │   └── Pipeline.jsx      # Visual representation of Producer -> Queue -> Handler
│   │   └── game/                 # Game arena, action bar, enemy sigils, health & run overlays
│   ├── lib/
│   │   ├── eventBus.js           # Local event queue & pub/sub broker implementation
│   │   ├── game.js               # Core game state & event producers
│   │   └── useGame.js            # React hook connecting UI to game/event state
│   └── routes/                   # Application views (Game, Events, Architecture)
├── events.md                     # Complete specification of all game events and payloads
├── architecture.md               # Detailed overview of Producers, Event Queue, and Handlers
├── package.json                  # Project dependencies and npm scripts
└── vite.config.js                # Vite development server configuration
```

---

## Prerequisites

* **Node.js** (v18 or higher recommended)
* **npm** (comes bundled with Node.js)

---

## Getting Started (Local Setup)

1. **Clone the repository:**
   ```bash
   git clone <YOUR_GITHUB_REPO_URL>
   cd <REPO_FOLDER_NAME>
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open the application in your browser:**
   Navigate to the local URL shown in the terminal (by default):
   ```text
   http://localhost:5173/
   ```

> **Note:** No external backend or API keys are required. The event queue runs completely locally in the browser, so any `[base44] No Base44 backend configured` console notice can be safely ignored.

---

## Documentation

* **`events.md`** — Lists every `event_name` and corresponding `event_payload` schema emitted during gameplay.
* **`architecture.md`** — Explains the Event-Driven Architecture, detailing the **Event Producers**, **Local Event Queue (`eventBus.js`)**, and **Event Handlers**.