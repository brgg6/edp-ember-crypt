const dot = {
  done: "bg-[#7BE495]",
  processing: "bg-[#6FA8FF]",
  retrying: "bg-[#FFB020]",
  dead: "bg-[#FF5A5A]",
  queued: "bg-[#5C544A]",
};

export function EventLog({ deliveries, counts }) {
  const rows = [...deliveries].sort((a, b) => b.at - a.at).slice(0, 80);

  return (
    <section className="flex h-full flex-col overflow-hidden rounded-2xl border border-[#2A2521] bg-[#141210]">
      <header className="flex items-center justify-between border-b border-[#2A2521] px-4 py-3">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#9A8F82]">Event queue</p>
        <p className="font-mono text-[10px] text-[#5C544A]">
          {counts.done || 0} delivered · {counts.dead || 0} dead
        </p>
      </header>

      <div className="max-h-[560px] flex-1 overflow-y-auto">
        {rows.length === 0 ? (
          <p className="px-4 py-12 text-center text-sm leading-relaxed text-[#7A6F62]">
            The queue is empty. Every action you take lands here.
          </p>
        ) : (
          <ul className="divide-y divide-[#201B17]">
            {rows.map((row) => (
              <li key={row.id} className="flex items-center gap-2 px-4 py-2 font-mono text-[10.5px]">
                <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${dot[row.status] || dot.queued}`} />
                <span className="flex-1 truncate text-[#E8DFD3]">{row.topic}</span>
                <span className="hidden truncate text-[#7A6F62] sm:block">{row.handlerLabel}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}