const tone = {
  done: "bg-[#FF9A3D]",
  processing: "bg-[#5AB0FF]",
  retrying: "bg-[#FFB020]",
  dead: "bg-[#FF5A5A]",
  queued: "bg-[#5C544A]",
};

function Column({ label, children }) {
  return (
    <div className="rounded-xl border border-[#2A2521] bg-[#141210] p-4">
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#9A8F82]">{label}</p>
      <div className="mt-3 space-y-2">{children}</div>
    </div>
  );
}

function Connector({ active }) {
  return (
    <div className="hidden items-center justify-center md:flex">
      <div className="relative h-px w-10 bg-[#2A2521]">
        {active && (
          <span className="absolute -top-[3px] left-0 h-[7px] w-[7px] animate-[flow_1.4s_linear_infinite] rounded-full bg-[#FF9A3D]" />
        )}
      </div>
    </div>
  );
}

export function Pipeline({ producers, handlers, deliveries, counts }) {
  const latest = (handlerId) =>
    deliveries.filter((d) => d.handlerId === handlerId).sort((a, b) => b.at - a.at)[0];
  const active = (counts.processing || 0) > 0;

  return (
    <div className="grid gap-3 md:grid-cols-[1fr_auto_1fr_auto_1.2fr]">
      <Column label="Producers">
        {producers.map((p) => (
          <div key={p.id} className="flex items-start gap-2">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#FF9A3D]" />
            <div>
              <p className="text-sm text-[#F2ECE4]">{p.label}</p>
              <p className="text-[11px] text-[#9A8F82]">{p.note}</p>
            </div>
          </div>
        ))}
      </Column>

      <Connector active={active} />

      <Column label="Event queue">
        <div className="flex items-baseline gap-2">
          <span className="font-heading text-3xl tabular-nums">{counts.queued || 0}</span>
          <span className="text-[11px] text-[#9A8F82]">waiting</span>
        </div>
        <div className="mt-1 flex gap-1">
          {Array.from({ length: 12 }).map((_, i) => (
            <span
              key={i}
              className={`h-6 flex-1 rounded-sm ${
                active && i < 8 ? "bg-[#FF9A3D]/60" : "bg-[#2A2521]"
              } ${active && i < 8 ? "animate-pulse" : ""}`}
            />
          ))}
        </div>
        <p className="text-[11px] text-[#9A8F82]">in-process · at-least-once delivery</p>
      </Column>

      <Connector active={active} />

      <Column label="Event handlers">
        {handlers.map((h) => {
          const last = latest(h.id);
          return (
            <div key={h.id} className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate text-sm text-[#F2ECE4]">{h.label}</p>
                <p className="truncate font-mono text-[10px] text-[#9A8F82]">
                  on {h.topics ? h.topics.join(" · ") : h.topic}
                </p>
              </div>
              <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${last ? tone[last.status] : "bg-[#2A2521]"}`} />
            </div>
          );
        })}
      </Column>
    </div>
  );
}