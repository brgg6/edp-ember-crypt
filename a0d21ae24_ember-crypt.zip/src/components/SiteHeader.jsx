import { Link } from "@tanstack/react-router";

const links = [
  { to: "/", label: "Crypt" },
  { to: "/events", label: "Events" },
  { to: "/architecture", label: "Architecture" },
];

export function SiteHeader({ active }) {
  return (
    <header className="sticky top-0 z-20 border-b border-[#2A2521] bg-[#0B0A09]/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-3">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="h-2 w-2 rotate-45 bg-[#FF9A3D]" />
          <span className="font-heading text-sm uppercase tracking-[0.16em]">Ember Crypt</span>
          <span className="hidden font-mono text-[10px] uppercase tracking-[0.18em] text-[#7A6F62] sm:inline">
            event-driven
          </span>
        </Link>
        <nav className="flex items-center gap-1">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`rounded-full px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] transition-colors ${
                active === link.to
                  ? "bg-[#2A2521] text-[#F2ECE4]"
                  : "text-[#9A8F82] hover:text-[#F2ECE4]"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}