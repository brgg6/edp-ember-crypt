export function RunOverlay({ status, score, wave, achievements, onStart, onRestart }) {
  if (status === "playing") return null;

  const over = status === "over";

  return (
    <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-[#0B0A09]/85 px-6 text-center backdrop-blur-sm">
      {over ? (
        <>
          <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-[#FF5A5A]">run over</p>
          <h2 className="font-heading text-3xl tracking-tight md:text-4xl">The crypt keeps you</h2>
          <p className="text-sm text-[#9A8F82]">
            Score <span className="text-[#FF9A3D] tabular-nums">{score}</span> · reached wave{" "}
            <span className="text-[#F2ECE4] tabular-nums">{wave}</span>
          </p>
          {achievements.length > 0 && (
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#7BE495]">
              {achievements.length} badge{achievements.length > 1 ? "s" : ""} earned
            </p>
          )}
          <button
            type="button"
            onClick={onRestart}
            className="mt-2 rounded-full bg-[#FF9A3D] px-6 py-2.5 text-sm font-medium text-[#1A1206] transition hover:bg-[#FFB067]"
          >
            Descend again
          </button>
        </>
      ) : (
        <>
          <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-[#FF9A3D]">
            event-driven dungeon
          </p>
          <h2 className="font-heading text-3xl leading-tight tracking-tight md:text-4xl">
            Every move is an event
          </h2>
          <p className="max-w-sm text-sm leading-relaxed text-[#9A8F82]">
            You publish <span className="font-mono text-[#E8DFD3]">PlayerActed</span>. Handlers resolve
            it, the enemy answers with its own event, and the queue carries it all.
          </p>
          <button
            type="button"
            onClick={onStart}
            className="mt-2 rounded-full bg-[#FF9A3D] px-6 py-2.5 text-sm font-medium text-[#1A1206] transition hover:bg-[#FFB067]"
          >
            Enter the crypt
          </button>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#5C544A]">
            keys 1 · 2 · 3
          </p>
        </>
      )}
    </div>
  );
}