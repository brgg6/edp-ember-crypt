const base =
  "group flex flex-col items-center justify-center gap-1 rounded-xl px-4 py-3 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-30";

export function ActionBar({ canAct, potions, onAction }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      <button
        type="button"
        onClick={() => onAction("attack")}
        disabled={!canAct}
        className={`${base} bg-[#FF9A3D] text-[#1A1206] hover:bg-[#FFB067]`}
      >
        Attack
        <span className="font-mono text-[9px] uppercase tracking-[0.18em] opacity-60">1</span>
      </button>
      <button
        type="button"
        onClick={() => onAction("block")}
        disabled={!canAct}
        className={`${base} border border-[#3A332C] text-[#E8DFD3] hover:border-[#6FA8FF] hover:text-[#6FA8FF]`}
      >
        Block
        <span className="font-mono text-[9px] uppercase tracking-[0.18em] opacity-60">2</span>
      </button>
      <button
        type="button"
        onClick={() => onAction("heal")}
        disabled={!canAct}
        className={`${base} border border-[#3A332C] text-[#E8DFD3] hover:border-[#7BE495] hover:text-[#7BE495]`}
      >
        Heal · {potions}
        <span className="font-mono text-[9px] uppercase tracking-[0.18em] opacity-60">3</span>
      </button>
    </div>
  );
}