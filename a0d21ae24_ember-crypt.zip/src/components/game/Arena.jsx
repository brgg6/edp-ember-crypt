import { EnemySigil } from "@/components/game/EnemySigil";
import { HealthBar } from "@/components/game/HealthBar";
import { ActionBar } from "@/components/game/ActionBar";
import { RunOverlay } from "@/components/game/RunOverlay";

export function Arena({ state, busy, canAct, onAction, onStart, onRestart }) {
  const enemy = state.enemy;
  const alive = Boolean(enemy && enemy.hp > 0);

  return (
    <section className="relative overflow-hidden rounded-2xl border border-[#2A2521] bg-[#141210]">
      <div className="flex items-center justify-between border-b border-[#2A2521] px-5 py-3">
        <div className="flex gap-5 font-mono text-[10px] uppercase tracking-[0.18em] text-[#9A8F82]">
          <span>
            wave <span className="text-[#F2ECE4] tabular-nums">{state.wave}</span>
          </span>
          <span>
            turn <span className="text-[#F2ECE4] tabular-nums">{state.turn}</span>
          </span>
          <span>
            score <span className="text-[#FF9A3D] tabular-nums">{state.score}</span>
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className={`h-1.5 w-1.5 rounded-full ${i < state.potions ? "bg-[#7BE495]" : "bg-[#2A2521]"}`}
            />
          ))}
          <span className="ml-1 font-mono text-[10px] uppercase tracking-[0.18em] text-[#9A8F82]">
            potions
          </span>
        </div>
      </div>

      <div className="relative px-5 py-7">
        <div className="flex flex-col items-center gap-4">
          <EnemySigil color={enemy?.sigil || "#FF9A3D"} alive={alive} busy={busy} />
          <div className="w-full max-w-xs text-center">
            <p className="font-heading text-xl tracking-tight">
              {alive ? enemy.name : "The crypt is quiet"}
            </p>
            {enemy && (
              <div className="mt-3">
                <HealthBar value={enemy.hp} max={enemy.maxHp} tone="enemy" label="Enemy" />
              </div>
            )}
          </div>
        </div>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-[#2A2521]" />
          <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-[#5C544A]">you</span>
          <div className="h-px flex-1 bg-[#2A2521]" />
        </div>

        <div className="space-y-2">
          <HealthBar value={state.hp} max={state.maxHp} label="Health" />
          <p className="h-4 font-mono text-[10px] uppercase tracking-[0.18em] text-[#6FA8FF]">
            {state.blocking ? "guarding · next hit reduced" : ""}
          </p>
        </div>

        <div className="mt-5">
          <ActionBar canAct={canAct} potions={state.potions} onAction={onAction} />
        </div>

        <RunOverlay
          status={state.status}
          score={state.score}
          wave={state.wave}
          achievements={state.achievements}
          onStart={onStart}
          onRestart={onRestart}
        />
      </div>
    </section>
  );
}