export function HealthBar({ value, max, tone = "player", label }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const bar = tone === "enemy" ? "bg-[#FF5A5A]" : "bg-[#7BE495]";

  return (
    <div>
      <div className="flex items-baseline justify-between font-mono text-[10px] uppercase tracking-[0.18em] text-[#9A8F82]">
        <span>{label}</span>
        <span className="tabular-nums">
          {Math.round(value)} / {max}
        </span>
      </div>
      <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-[#241F1B]">
        <div
          className={`h-full rounded-full transition-all duration-500 ${bar}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}