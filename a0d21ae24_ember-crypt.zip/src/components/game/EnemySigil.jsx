export function EnemySigil({ color, alive, busy }) {
  return (
    <div className="relative h-28 w-28 shrink-0">
      <div
        className="absolute inset-0 rounded-full opacity-30 blur-2xl"
        style={{ background: color }}
      />
      <div
        className="absolute inset-2 rounded-full border transition-opacity duration-500"
        style={{ borderColor: color, opacity: alive ? 0.7 : 0.15 }}
      />
      <div
        className={`absolute inset-6 rounded-full border ${alive && busy ? "animate-pulse" : ""}`}
        style={{ borderColor: color, opacity: alive ? 0.45 : 0.12 }}
      />
      <div
        className="absolute inset-11 rounded-full transition-opacity duration-500"
        style={{ background: color, opacity: alive ? 0.9 : 0.18 }}
      />
    </div>
  );
}