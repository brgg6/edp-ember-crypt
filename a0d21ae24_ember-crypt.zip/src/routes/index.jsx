import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { Arena } from "@/components/game/Arena";
import { EventLog } from "@/components/edp/EventLog";
import { useGame } from "@/lib/useGame";

export const Route = createFileRoute("/")({
  component: CryptPage,
  head: () => ({
    meta: [
      { title: "Ember Crypt — Event-Driven Game" },
      {
        name: "description",
        content:
          "A turn-based dungeon crawl where every action is an event on a local event queue, resolved by event handlers.",
      },
    ],
  }),
});

const KEYS = { "1": "attack", "2": "block", "3": "heal" };

function CryptPage() {
  const { state, deliveries, counts, busy, start, act, restart } = useGame();
  const canAct = state.status === "playing" && !busy;

  useEffect(() => {
    const onKey = (event) => {
      if (event.key === "Enter") {
        if (state.status === "ready") start();
        else if (state.status === "over") restart();
        return;
      }
      const action = KEYS[event.key];
      if (action && canAct) act(action);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [canAct, state.status, act, start, restart]);

  return (
    <div className="min-h-screen bg-[#0B0A09] text-[#F2ECE4]">
      <SiteHeader active="/" />
      <main className="mx-auto max-w-6xl px-6 py-8 md:py-10">
        <div className="grid gap-4 lg:grid-cols-[1.55fr_1fr]">
          <Arena
            state={state}
            busy={busy}
            canAct={canAct}
            onAction={act}
            onStart={start}
            onRestart={restart}
          />
          <EventLog deliveries={deliveries} counts={counts} />
        </div>

        <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.18em] text-[#5C544A]">
          Local event queue · retries ×3 · dead-letter → DeliveryFailed
        </p>
      </main>
    </div>
  );
}