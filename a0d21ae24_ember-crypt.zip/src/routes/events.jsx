import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { eventCatalog } from "@/lib/catalog";

export const Route = createFileRoute("/events")({
  component: EventsPage,
  head: () => ({
    meta: [
      { title: "Events — Ember Crypt" },
      {
        name: "description",
        content: "Every event in Ember Crypt: producer, payload fields and the handlers that subscribe.",
      },
    ],
  }),
});

function EventsPage() {
  return (
    <div className="min-h-screen bg-[#0B0A09] text-[#F2ECE4]">
      <SiteHeader active="/events" />
      <main className="mx-auto max-w-6xl px-6 py-10 md:py-14">
        <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#FF9A3D]">
          {eventCatalog.length} events
        </p>
        <h1 className="mt-3 font-heading text-4xl leading-[1.03] tracking-tight md:text-5xl">
          Event catalog
        </h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#9A8F82]">
          Every message the crypt puts on the queue. The same catalog lives in{" "}
          <span className="font-mono text-[#E8DFD3]">events.md</span> at the root of the repository.
        </p>

        <div className="mt-8 grid gap-3 md:grid-cols-2">
          {eventCatalog.map((event) => (
            <article key={event.name} className="rounded-xl border border-[#2A2521] bg-[#141210] p-5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h2 className="font-mono text-sm text-[#FF9A3D]">{event.name}</h2>
                <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-[#9A8F82]">
                  {event.producer}
                </span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-[#D8CFC4]">{event.summary}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {event.payload.map((field) => (
                  <span
                    key={field}
                    className="rounded border border-[#3A332C] px-1.5 py-0.5 font-mono text-[10px] text-[#9A8F82]"
                  >
                    {field}
                  </span>
                ))}
              </div>
              <p className="mt-3 border-t border-[#201B17] pt-3 text-[11px] text-[#9A8F82]">
                Handled by {event.subscribers.join(", ")}
              </p>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}