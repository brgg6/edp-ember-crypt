import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { Pipeline } from "@/components/edp/Pipeline";
import { handlerMeta, producers } from "@/lib/game";

export const Route = createFileRoute("/architecture")({
  component: ArchitecturePage,
  head: () => ({
    meta: [
      { title: "Architecture — Ember Crypt" },
      {
        name: "description",
        content:
          "How the game works: event producers, the local event queue and the event handlers that run the dungeon.",
      },
    ],
  }),
});

const steps = [
  {
    n: "01",
    title: "Input publishes",
    body: "Pressing Attack publishes PlayerActed. The input layer knows nothing about combat, score or loot.",
  },
  {
    n: "02",
    title: "Queue fans out",
    body: "The queue creates one delivery per subscribed handler and runs them one at a time, in order.",
  },
  {
    n: "03",
    title: "Handlers resolve",
    body: "ResolveAction computes damage and publishes EnemyDamaged or EnemyDefeated. Nobody calls it directly.",
  },
  {
    n: "04",
    title: "The enemy answers",
    body: "CloseTurn ends the turn, EnemyTurn rolls the counter-attack and publishes PlayerDamaged. The loop continues.",
  },
];

const guarantees = [
  {
    title: "At-least-once delivery",
    body: "A delivery is only marked done after the handler resolves, so no hit or drop is silently lost.",
  },
  {
    title: "Retry with backoff",
    body: "A thrown error is a technical failure. The queue retries three times before giving up.",
  },
  {
    title: "Dead-letter queue",
    body: "LeaderboardSync is deliberately offline. Its failures dead-letter and publish DeliveryFailed, which Telemetry picks up — the run keeps going.",
  },
  {
    title: "Rejection is not failure",
    body: "Healing with no potions publishes ActionRejected instead of throwing. The turn still closes normally.",
  },
];

function ArchitecturePage() {
  return (
    <div className="min-h-screen bg-[#0B0A09] text-[#F2ECE4]">
      <SiteHeader active="/architecture" />
      <main className="mx-auto max-w-6xl px-6 py-10 md:py-14">
        <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#FF9A3D]">
          producers → queue → handlers
        </p>
        <h1 className="mt-3 font-heading text-4xl leading-[1.03] tracking-tight md:text-5xl">
          How the crypt works
        </h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#9A8F82]">
          The game has no central game loop calling systems. Input publishes an event, the queue
          delivers it, and handlers publish the next one.
        </p>

        <div className="mt-8">
          <Pipeline producers={producers} handlers={handlerMeta} deliveries={[]} counts={{}} />
        </div>

        <section className="mt-10 grid gap-3 md:grid-cols-2">
          {steps.map((step) => (
            <article key={step.n} className="rounded-xl border border-[#2A2521] bg-[#141210] p-5">
              <span className="font-mono text-[10px] tracking-[0.2em] text-[#FF9A3D]">{step.n}</span>
              <h2 className="mt-2 font-heading text-lg tracking-tight">{step.title}</h2>
              <p className="mt-1.5 text-sm leading-relaxed text-[#9A8F82]">{step.body}</p>
            </article>
          ))}
        </section>

        <section className="mt-10">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#9A8F82]">
            Delivery guarantees
          </h2>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {guarantees.map((item) => (
              <article key={item.title} className="rounded-xl border border-[#2A2521] bg-[#141210] p-5">
                <h3 className="text-sm text-[#F2ECE4]">{item.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[#9A8F82]">{item.body}</p>
              </article>
            ))}
          </div>
        </section>

        <p className="mt-8 font-mono text-[11px] text-[#5C544A]">
          Full write-up with a diagram: architecture.md at the root of the repository.
        </p>
      </main>
    </div>
  );
}